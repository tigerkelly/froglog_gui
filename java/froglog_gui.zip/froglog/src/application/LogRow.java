package application;

import java.sql.Timestamp;

public class LogRow {
	private Timestamp ts;
	private String logMsg;
	
	public LogRow(Timestamp ts, String logMsg) {
		this.ts = ts;
		this.logMsg = logMsg;
	}

	public Timestamp getTs() {
		return ts;
	}

	public void setTs(Timestamp ts) {
		this.ts = ts;
	}

	public String getLogMsg() {
		return logMsg;
	}

	public void setLogMsg(String logMsg) {
		this.logMsg = logMsg;
	}
}
