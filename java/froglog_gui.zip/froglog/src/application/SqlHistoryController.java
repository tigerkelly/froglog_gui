package application;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

import org.apache.commons.io.FileUtils;

import ipcs.SqlChangeEvent;
import ipcs.SqlChanges;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;

public class SqlHistoryController implements Initializable, RefreshScene {

    @FXML private ListView<String> lvHistory;
    
    private FlGlobal fg = FlGlobal.getInstance();
    
    @FXML
    void btnResetReleased(MouseEvent event) {

    }
    
    @FXML
    void btnBackReleased(MouseEvent event) {
    	SceneNav.scenePop();
    }
    
    @FXML
    void btnDeleteReleased(MouseEvent event) {
    	Alert alert = new Alert(AlertType.CONFIRMATION);
    	alert.setTitle("Delete History");
    	alert.setHeaderText("Delete Confirmation Dialog");
    	alert.setContentText("Delete selected SQL from history?");

    	Optional<ButtonType> result = alert.showAndWait();
    	if (result.get() == ButtonType.OK) {
    	    String sql = lvHistory.getSelectionModel().getSelectedItem().trim();
//    	    sql = sql.replaceAll("\\s+", " ");
    	    
    	    File hFile = new File(fg.baseDir + "/sqlhistory.txt");
        	if (hFile.exists() == true) {
        		
    	    	String txt = null;
    			try {
    				txt = FileUtils.readFileToString(hFile, "UTF-8");
    			} catch (IOException e) {
    				e.printStackTrace();
    			}
    	    	
    			if (txt != null) {
    				String a[] = txt.split("\n");
    				
    				FileWriter fw = null;
					try {
						fw = new FileWriter(hFile, false);
						for (String s : a) {
							s = s.trim();
	    					if (s.equals(sql) == false) {
	    						fw.write(s + "\n");
	    					}
	    				}
						fw.close();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
    			}
        	}
        	fillList();
    	} else {
    	    // ... user chose CANCEL or closed the dialog
    	}
    }
    

    @FXML
    void btnSelectSqlReleased(MouseEvent event) {

    	int num = lvHistory.getSelectionModel().getSelectedIndex();
    	
	    if (num >= 0) {
	    	String s = lvHistory.getSelectionModel().getSelectedItem();
	    	fg.sqlChange.fireChange(new SqlChangeEvent(SqlChanges.SQLCHANGED, s));
	    }
	    
	    SceneNav.scenePop();
    }
    
    @Override
	public void initialize(URL arg0, ResourceBundle arg1) {
    	fillList();
	}
    
    private void fillList() {
    	File hFile = new File(fg.baseDir + "/sqlhistory.txt");
    	if (hFile.exists() == true) {
    		lvHistory.getItems().clear();
    		
	    	String txt = null;
			try {
				txt = FileUtils.readFileToString(hFile, "UTF-8");
			} catch (IOException e) {
				e.printStackTrace();
			}
	    	
			if (txt != null) {
				String a[] = txt.split("\n");
				
				for(String s : a) {
					lvHistory.getItems().add(s.trim());
				}
			}
    	}
    }


	@Override
	public void refreshScene() {
		lvHistory.getItems().clear();
		fillList();
	}

	@Override
	public void leaveScene() {
		
	}

	@Override
	public void clickIt(String text, WidgetType widgetType) {
		
	}
}

