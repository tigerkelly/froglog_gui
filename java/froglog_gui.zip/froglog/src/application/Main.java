package application;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.DriverManager;
import java.util.Timer;
import java.util.TimerTask;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.Stage;

public class Main extends Application {
	
	private FlGlobal fg = FlGlobal.getInstance();
	private Pane mainPane = null;
	
	@Override
	public void start(Stage primaryStage) {

		try {
			Class.forName("org.postgresql.Driver");
//			fg.conn = DriverManager.getConnection("jdbc:postgresql://192.168.0.30:5432/froglogdb", "froglog", "LetFroglogin2");
			fg.conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/froglogdb", "froglog", "LetFroglogin2");
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
//		System.out.println("Opened database successfully");
		
//		System.out.println("Version: " + fg.version);

		Thread.setDefaultUncaughtExceptionHandler(Main::showError);
		
		try {
			primaryStage.setScene(createScene(loadMainPane()));
		} catch (IOException e) {
			e.printStackTrace();
		}

		Rectangle2D r = Screen.getPrimary().getBounds();
//		System.out.println(r);
		
		int heightOffset = (int)(r.getHeight() - 900.0);
		if (heightOffset < 0)
			heightOffset = 10;
		int widthOffset = (int)((r.getWidth() - 1280.0) / 2.0);
		
		primaryStage.setY(heightOffset);
		primaryStage.setX(widthOffset);
		
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
	 
	/**
     * Loads the main fxml layout.
     * Sets up the vista switching VistaNavigator.
     * Loads the first vista into the fxml layout.
     *
     * @return the loaded pane.
     * @throws IOException if the pane could not be loaded.
     */
//    @SuppressWarnings("resource")
	private Pane loadMainPane() throws IOException {
        FXMLLoader loader = new FXMLLoader();

        mainPane = (Pane) loader.load(getClass().getResourceAsStream(SceneNav.MAIN));	// SceneNav

        SceneNavController mainController = loader.getController();

        SceneNav.setMainController(mainController);
        SceneNav.loadScene(SceneNav.FROGLOG);

        return mainPane;
    }

    /**
     * Creates the main application scene.
     *
     * @param mainPane the main application layout.
     *
     * @return the created scene.
     */
    private Scene createScene(Pane mainPane) {
        Scene scene = new Scene(mainPane);

        scene.getStylesheets().setAll(getClass().getResource("application.css").toExternalForm());

        return scene;
    }
    
	private static void showError(Thread t, Throwable e) {
//		System.err.println("***Default exception handler***");
		if (Platform.isFxApplicationThread()) {
			if (e.getMessage().contains("Too many touch")) {
				e.printStackTrace();
				showErrorDialog(e);
			} else {
				System.out.println("Error: exception: " + e);
				e.printStackTrace();
			}
		} else {
			System.err.println("An unexpected error occurred in " + t);

		}
	}
	
	private static void showErrorDialog(Throwable e) {
        StringWriter errorMsg = new StringWriter();
        e.printStackTrace(new PrintWriter(errorMsg));
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("Error.fxml"));
        try {
            Parent root = loader.load();
            ((ErrorController)loader.getController()).setErrorText(errorMsg.toString());
            dialog.setScene(new Scene(root, 1000, 700));
            dialog.show();
            
            Timer timer = new Timer();
            
            TimerTask task = new TimerTask() {
            	public void run() {
            		System.exit(1);
            	}
            };
            
            timer.schedule(task, 10000);
        } catch (IOException exc) {
            exc.printStackTrace();
        }
    }
}
