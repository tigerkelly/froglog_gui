package application;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListView;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class ControllerStub implements Initializable, RefreshScene {

    @FXML private ListView<?> logList;
    @FXML private TableView<?> logTable;
    @FXML private TextField tfSearch;
    @FXML private DatePicker dpDate;
    @FXML private Button btnReset;

    @FXML
    void btnResetReleased(MouseEvent event) {

    }
    
    @Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
	}

	@Override
	public void refreshScene() {
		
	}

	@Override
	public void leaveScene() {
		
	}

	@Override
	public void clickIt(String text, WidgetType widgetType) {
		
	}
}

