package application;

import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.MenuItem;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;

public class FrogLogController implements Initializable, RefreshScene {

    @FXML private ListView<String> logList;
    @FXML private TableView<LogRow> logMsgs;
    @FXML private TextField tfSearch;
    @FXML private DatePicker dpDate;
    @FXML private Button btnReset;
    @FXML private Label lblVersion;
    @FXML private TableColumn<LogRow, String> tcTimestamp;
    @FXML private TableColumn<LogRow, String> tcMessage;
    
    private FlGlobal fg = FlGlobal.getInstance();

    @FXML
    void btnResetReleased(MouseEvent event) {
    	dpDate.setValue(null);
    	tfSearch.setText("");
    }
    
    @FXML
    void btnSearchReleased(MouseEvent event) {
    	String s = logList.getSelectionModel().getSelectedItem();
    	if (s != null) {
    		String[] a = s.split("\\s");
    		fillTable(a[0]);
    	}
    }
    
    @FXML
    void btnSqlSearchReleased(MouseEvent event) {
    	fg.loadSceneNav(SceneNav.SQL);
    }
    
    @FXML
    void tfOnEnter(ActionEvent event) {
    	String s = logList.getSelectionModel().getSelectedItem();
    	if (s != null) {
    		String[] a = s.split("\\s");
    		fillTable(a[0]);
    	}
    }
    
    @FXML
    void btnReloadTablesReleased(MouseEvent event) {
    	Scene s = logList.getParent().getScene();
		s.setCursor(Cursor.WAIT);
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				fillList();
				Scene s = logList.getParent().getScene();
				s.setCursor(Cursor.DEFAULT);
			}
		});
    }
    
    @Override
	public void initialize(URL arg0, ResourceBundle arg1) {
    	
    	lblVersion.setText("Version: " + fg.version);
    	
    	logMsgs.setPlaceholder(new Label("No table selected."));
    	
    	tcTimestamp.setCellValueFactory(new PropertyValueFactory<LogRow, String>("ts"));
    	tcMessage.setCellValueFactory(new PropertyValueFactory<LogRow, String>("logMsg"));
    	
    	ContextMenu menu = new ContextMenu();
    	
    	MenuItem query = new MenuItem("Query Table");
    	MenuItem purge = new MenuItem("Purge Table");
    	MenuItem create = new MenuItem("Create Table");
    	MenuItem delete = new MenuItem("Delete Table");
    	
    	menu.getItems().addAll(query, purge, create, delete);
    	
    	logList.setContextMenu(menu);
    	
    	purge.setOnAction(new EventHandler<ActionEvent>() {
    	    @Override
    	    public void handle(ActionEvent event) {
//    	        System.out.println("Purge...");
    	        Alert alert = new Alert(AlertType.CONFIRMATION);
    	    	alert.setTitle("Purge Table");
    	    	alert.setHeaderText("Purge all rows form table.");
    	    	alert.setContentText("Purge all rows from table?\nNote: Cannot be undone.");

    	    	Optional<ButtonType> result = alert.showAndWait();
    	    	if (result.get() == ButtonType.OK) {
    	    		Dialog<String> dialog = new Dialog<>();
    	    		dialog.setTitle("Password Dialog");
    	    		dialog.setHeaderText("Enter Admin password");

    	    		// Set the icon (must be included in the project).

    	    		// Set the button types.
    	    		ButtonType loginButtonType = new ButtonType("OK", ButtonData.OK_DONE);
    	    		dialog.getDialogPane().getButtonTypes().addAll(loginButtonType, ButtonType.CANCEL);

    	    		// Create the username and password labels and fields.
    	    		GridPane grid = new GridPane();
    	    		grid.setHgap(10);
    	    		grid.setVgap(10);
    	    		grid.setPadding(new Insets(20, 150, 10, 10));

    	    		PasswordField password = new PasswordField();
    	    		password.setPromptText("Password");

    	    		grid.add(new Label("Password:"), 0, 0);
    	    		grid.add(password, 1, 0);

    	    		dialog.getDialogPane().setContent(grid);

    	    		// Request focus on the password field by default.
    	    		Platform.runLater(() -> password.requestFocus());

    	    		// Convert the result to a username-password-pair when the login button is clicked.
    	    		dialog.setResultConverter(dialogButton -> {
    	    		    if (dialogButton == loginButtonType) {
    	    		        return password.getText();
    	    		    }
    	    		    return null;
    	    		});

    	    		Optional<String> rs = dialog.showAndWait();

    	    		rs.ifPresent(usernamePassword -> {
//    	    		    System.out.println("Password: " + rs.get());
    	    			byte[] hash1 = null;
    	    			try {
							MessageDigest digest = MessageDigest.getInstance("SHA-256");
							hash1 = digest.digest(rs.get().getBytes(StandardCharsets.UTF_8));
						} catch (NoSuchAlgorithmException e1) {
							e1.printStackTrace();
						}
    	    			String p1 = bytesToHex(hash1);
//    	    			System.out.println(p1 + ", " + fg.adminPassword + ", " + rs.get());
    	    		    if (fg.adminPassword.equals(p1)) {
    	    		    	try {
    	    		    		String s = logList.getSelectionModel().getSelectedItem();
    	    		    		String tableName = null;
    	    		    		if (s != null) {
    	    		    			String[] a = s.split("\\s");
        	    		    		tableName = a[0];
    	    		    			String sql = String.format("delete from %s;", tableName);
    	    		    			Statement st = fg.conn.createStatement();
    	    		    			st.execute(sql);
    	    		    			st.close();
    	    		    		}
    	    		    		fillTable(tableName);
    	    		    	} catch (SQLException e) {
    	    		    		e.printStackTrace();
    	    		    	}
    	    		    }
    	    		
    	    		});
    	    	}
    	    }
    	});
    	
    	query.setOnAction(new EventHandler<ActionEvent>() {
    	    @Override
    	    public void handle(ActionEvent event) {
//    	        System.out.println("Truncate...");
    	    	String s1 = logList.getSelectionModel().getSelectedItem();
    	    	
        		if (s1 != null) {
        			String[] a = s1.split("\\s");
        			String tableName = a[0];
        			Scene s = logMsgs.getParent().getScene();
 	        	    s.setCursor(Cursor.WAIT);
        			Platform.runLater(new Runnable() {
        				@Override
        				public void run() {
        					fillTable(tableName);
        					Scene s = logMsgs.getParent().getScene();
        					s.setCursor(Cursor.DEFAULT);
        				}
        			});
        		}
    	    }
    	});
    	
    	create.setOnAction(new EventHandler<ActionEvent>() {
    		@Override
    		public void handle(ActionEvent event) {
//    			System.out.println("Create---");

	    		Dialog<String> dialog = new Dialog<>();
	    		dialog.setTitle("Create Table Dialog");
	    		dialog.setHeaderText("Enter Table Name and Admin password");

	    		// Set the icon (must be included in the project).

	    		// Set the button types.
	    		ButtonType loginButtonType = new ButtonType("OK", ButtonData.OK_DONE);
	    		dialog.getDialogPane().getButtonTypes().addAll(loginButtonType, ButtonType.CANCEL);

	    		// Create the username and password labels and fields.
	    		GridPane grid = new GridPane();
	    		grid.setHgap(10);
	    		grid.setVgap(10);
	    		grid.setPadding(new Insets(20, 150, 10, 10));

	    		TextField table = new TextField();
	    		table.setPromptText("Enter Table Name");
	    		
	    		PasswordField password = new PasswordField();
	    		password.setPromptText("Password");

	    		grid.add(new Label("Table Name:"), 0, 0);
	    		grid.add(table, 1, 0);
	    		grid.add(new Label("Password:"), 0, 1);
	    		grid.add(password, 1, 1);

	    		dialog.getDialogPane().setContent(grid);

	    		// Request focus on the table name field by default.
	    		Platform.runLater(() -> table.requestFocus());

	    		// Convert the result to a username-password-pair when the login button is clicked.
	    		dialog.setResultConverter(dialogButton -> {
	    		    if (dialogButton == loginButtonType) {
	    		        return password.getText();
	    		    }
	    		    return null;
	    		});

	    		Optional<String> rs = dialog.showAndWait();

	    		rs.ifPresent(usernamePassword -> {
//    	    		    System.out.println("Password: " + rs.get());
	    			byte[] hash1 = null;
	    			try {
						MessageDigest digest = MessageDigest.getInstance("SHA-256");
						hash1 = digest.digest(rs.get().getBytes(StandardCharsets.UTF_8));
					} catch (NoSuchAlgorithmException e1) {
						e1.printStackTrace();
					}
	    			String p1 = bytesToHex(hash1);
//    	    			System.out.println(p1 + ", " + fg.adminPassword + ", " + rs.get());
	    		    if (fg.adminPassword.equals(p1)) {
	    		    	try {
	    		    		String tableName = table.getText();
	    		    		tableName = tableName.replaceAll("\\s+", "_");
	    		    		if (tableName != null) {
	    		    			String sql = String.format("create table %s (ts timestamptz NOT NULL DEFAULT NOW(), logmsg text);", tableName);
//	    		    			System.out.println(sql);
	    		    			Statement st = fg.conn.createStatement();
	    		    			st.execute(sql);
	    		    			st.close();
	    		    		}
	    		    		
	    		    		fillList();
	    		    		fg.sendToFroglog("TaBleCreAted:GUI created table.");
	    		    	} catch (SQLException e) {
	    		    		e.printStackTrace();
	    		    	}
	    		    }
	    		
	    		});
	    	}
    	});
    	
    	delete.setOnAction(new EventHandler<ActionEvent>() {
    	    @Override
    	    public void handle(ActionEvent event) {
//    	        System.out.println("Delete...");
    	        Alert alert = new Alert(AlertType.CONFIRMATION);
    	    	alert.setTitle("Delete Table");
    	    	alert.setHeaderText("Delete table from database.");
    	    	alert.setContentText("Delete selected table?\nNote: Cannot be undone.");

    	    	Optional<ButtonType> result = alert.showAndWait();
    	    	if (result.get() == ButtonType.OK) {
    	    		Dialog<String> dialog = new Dialog<>();
    	    		dialog.setTitle("Password Dialog");
    	    		dialog.setHeaderText("Enter Admin password");

    	    		// Set the icon (must be included in the project).

    	    		// Set the button types.
    	    		ButtonType loginButtonType = new ButtonType("OK", ButtonData.OK_DONE);
    	    		dialog.getDialogPane().getButtonTypes().addAll(loginButtonType, ButtonType.CANCEL);

    	    		// Create the username and password labels and fields.
    	    		GridPane grid = new GridPane();
    	    		grid.setHgap(10);
    	    		grid.setVgap(10);
    	    		grid.setPadding(new Insets(20, 150, 10, 10));

    	    		PasswordField password = new PasswordField();
    	    		password.setPromptText("Password");

    	    		grid.add(new Label("Password:"), 0, 0);
    	    		grid.add(password, 1, 0);

    	    		dialog.getDialogPane().setContent(grid);

    	    		// Request focus on the password field by default.
    	    		Platform.runLater(() -> password.requestFocus());

    	    		// Convert the result to a username-password-pair when the login button is clicked.
    	    		dialog.setResultConverter(dialogButton -> {
    	    		    if (dialogButton == loginButtonType) {
    	    		        return password.getText();
    	    		    }
    	    		    return null;
    	    		});

    	    		Optional<String> rs = dialog.showAndWait();

    	    		rs.ifPresent(usernamePassword -> {
//    	    		    System.out.println("Password: " + rs.get());
    	    			byte[] hash1 = null;
    	    			try {
							MessageDigest digest = MessageDigest.getInstance("SHA-256");
							hash1 = digest.digest(rs.get().getBytes(StandardCharsets.UTF_8));
						} catch (NoSuchAlgorithmException e1) {
							e1.printStackTrace();
						}
    	    			String p1 = bytesToHex(hash1);
//    	    			System.out.println(p1 + ", " + fg.adminPassword + ", " + rs.get());
    	    		    if (fg.adminPassword.equals(p1)) {
    	    		    	try {
    	    		    		String s = logList.getSelectionModel().getSelectedItem();
    	    		    		if (s != null) {
    	    		    			String[] a = s.split("\\s");
    	    		    			String tableName = a[0];
    	    		    			String sql = String.format("drop table %s;", tableName);
    	    		    			Statement st = fg.conn.createStatement();
    	    		    			st.execute(sql);
    	    		    			st.close();
    	    		    		}
    	    		    		
    	    		    		fillList();
    	    		    		logMsgs.getItems().clear();
    	    		    		fg.sendToFroglog("TaBleDeleTed:GUI deleted table.");
    	    		    	} catch (SQLException e) {
    	    		    		e.printStackTrace();
    	    		    	}
    	    		    }
    	    		
    	    		});
    	    	}
    	    }
    	});
    	
    	logList.setOnMouseClicked(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent click) {

				if (click.getClickCount() == 2) {
					String s1 = logList.getSelectionModel().getSelectedItem();

					if (s1 != null) {
						String[] a = s1.split("\\s");
						String tableName = a[0];
						Scene s = logMsgs.getParent().getScene();
						s.setCursor(Cursor.WAIT);
						Platform.runLater(new Runnable() {
							@Override
							public void run() {
								fillTable(tableName);
								Scene s = logMsgs.getParent().getScene();
								s.setCursor(Cursor.DEFAULT);
							}
						});
					}
				}
			}
		});
    	
    	
		fillList();
	}
    
    private void fillTable(String tableName) {
    	logMsgs.getItems().clear();
//    	System.out.println("Cleared table.");
    	
    	if (tableName == null || tableName.length() <= 0)
    		return;
    	
    	String searchDate = null;
    	String searchText = null;
    	String sql = null;
    	
    	searchText = tfSearch.getText();
    	LocalDate d = dpDate.getValue();
    	
    	if (d != null)
    		searchDate = d.toString();
    	
    	String s1 = null;
    	String s2 = null;
    	
    	if (searchDate != null && searchDate.length() > 0)
    		s1 = String.format("DATE(ts) = '%s'", searchDate);
    	
    	if (searchText != null && searchText.length() > 0) {
    		if (searchText.contains("%") || searchText.contains("_") || searchText.contains("[") || searchText.contains("]"))
    			s2 = String.format("logmsg like '%s'", searchText);
    		else
    			s2 = String.format("logmsg like '%%%s%%'", searchText);
    	}
    	
    	if (s1 == null && s2 == null)
    		logMsgs.setPlaceholder(new Label("Log table is empty."));
    	else
    		logMsgs.setPlaceholder(new Label("No rows found matching search pattern."));
    	
    	if (s1 != null && s2 != null)
    		sql = String.format("select * from %s where %s and %s order by ts;", tableName, s1, s2);
    	else if (s1 != null && s2 == null)
    		sql = String.format("select * from %s where %s order by ts;", tableName, s1);
    	else if (s1 == null && s2 != null)
    		sql = String.format("select * from %s where %s order by ts;", tableName, s2);
    	else
    		sql = String.format("select * from %s order by ts;", tableName);
    	
//    	System.out.println(sql);
    	
    	ObservableList<LogRow> items = FXCollections.<LogRow>observableArrayList();
    	
    	try {
			Statement st = fg.conn.createStatement();
			ResultSet rs = st.executeQuery(sql);
			
			List<LogRow> lst = new ArrayList<LogRow>();
			
			while(rs.next()) {
				Timestamp ts = rs.getTimestamp(1);
				String logMsg = rs.getString(2);
				
//				System.out.println(ts.toString() + ", " + logMsg);
				
				LogRow lr = new LogRow(ts, logMsg);
				
				lst.add(lr);
			}
			
			items.addAll(lst);
			
			logMsgs.setItems(items);
			
			rs.close();
			st.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }
    
    private void fillList() {
    	
    	logList.getItems().clear();
    	try {
			Statement st = fg.conn.createStatement();
			ResultSet rs = st.executeQuery("select table_name from information_schema.tables " +
						"where table_schema = 'public' " + 
						"order by table_name;");
			while (rs.next()) {
				String tableName = rs.getString(1);
				
				Statement st2 = fg.conn.createStatement();
				ResultSet rs2 = st2.executeQuery("select COUNT(*) from " + tableName + ";");
				int num = 0;
				if (rs2.next() )
					num = rs2.getInt(1);
				
				rs2.close();
				st2.close();
				
				logList.getItems().add(tableName + " (" + num + ")");
			}
			rs.close();
			st.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }
    
    private static String bytesToHex(byte[] hash) {
        StringBuilder hexString = new StringBuilder(2 * hash.length);
        for (int i = 0; i < hash.length; i++) {
            String hex = Integer.toHexString(0xff & hash[i]);
            if(hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }

	@Override
	public void refreshScene() {
		
	}

	@Override
	public void leaveScene() {
		
	}

	@Override
	public void clickIt(String text, WidgetType widgetType) {
		
	}
}

