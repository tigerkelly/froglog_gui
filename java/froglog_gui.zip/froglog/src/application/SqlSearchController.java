package application;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

import org.apache.commons.io.FileUtils;

import ipcs.SqlChangeEvent;
import ipcs.SqlChangeListener;
import ipcs.SqlChanges;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.web.WebView;

public class SqlSearchController implements Initializable, RefreshScene {

    @FXML private TextArea taTables;
    @FXML private TextField tfSearch;
    @FXML private DatePicker dpDate;
    @FXML private Button btnReset;
    @FXML private TextArea taSql;
    @FXML private WebView wvSqlResults;
    
    private FlGlobal fg = FlGlobal.getInstance();

    @FXML
    void btnReloadTablesReleased(MouseEvent event) {
    	fillList();
    }
    
    @FXML
    void btnResetReleased(MouseEvent event) {

    }
    
    @FXML
    void btnHistoryReleased(MouseEvent event) {
    	fg.loadSceneNav(SceneNav.SQLHISTORY);
    }
    
    @FXML
    void btnClearReleased(MouseEvent event) {
    	wvSqlResults.getEngine().loadContent("");
    }
    
    @FXML
    void btnSqlSearchReleased(MouseEvent event) {
    	getSqlResults();
    }
    
    @FXML
    void btnSqlHistoryReleased(MouseEvent event) {
    	fg.loadSceneNav(SceneNav.SQLHISTORY);
    }
    
    @FXML
    void btnBackReleased(MouseEvent event) {
    	SceneNav.scenePop();
    }
    
    @Override
	public void initialize(URL arg0, ResourceBundle arg1) {
    	fg.sqlChange.addChangeListener(new SqlChangeListener() {
			
			@Override
			public void changeEventOccurred(SqlChangeEvent evt) {
				
				if (evt.type == SqlChanges.SQLCHANGED) {
					taSql.setText(evt.data);
				}
			}
    	});
    	
    	fillList();
	}
    
    private void getSqlResults() {
    	String sql = taSql.getText();
    	
    	sql = sql.trim();
    	
    	if (sql == null || sql.length() <= 0)
    		return;
    	
    	sql = sql.replaceAll("\n", " ");
    	
    	wvSqlResults.getEngine().loadContent("");
    	
    	File tf = null;
    	try {
			tf = File.createTempFile("tmp", ".sql", new File(fg.baseDir));
		} catch (IOException e1) {
			e1.printStackTrace();
			return;
		}
    	
    	String[] args = new String[3];
		args[0] = "/home/froglog/bin/sql.sh";
		args[1] = tf.getAbsolutePath();
		args[2] = sql;
		
		saveHistory(sql);
		
		int exitValue = 0;
		
		try {
			ProcessBuilder pb = new ProcessBuilder();
			pb.command(args);

			Process process = pb.start();
			
			StreamGobbler inGobbler = new StreamGobbler(process.getInputStream(), false);
			inGobbler.start();

			exitValue = process.waitFor();
			
			if (exitValue != 0) {
				System.out.println("Exec of SQL failed.");
				return;
			}
//			System.out.println("exitValue: " + exitValue);
			
			String txt = FileUtils.readFileToString(tf, "UTF-8");
			
			int width = (int)wvSqlResults.getWidth() - 30;
		    
		    txt = txt.replace("border=\"1\"", String .format("border=\"1\" width=\"%dpx\"", width));
		    txt = txt.replace(">ts<", " width=\"275px\">ts<");
		    
		    if (txt != null)
		    	wvSqlResults.getEngine().loadContent(txt);

		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		if (tf != null)
			tf.delete();
    }
    
    private void fillList() {
    	
    	taTables.setText("");
    	try {
			Statement st = fg.conn.createStatement();
			ResultSet rs = st.executeQuery("select table_name from information_schema.tables " +
						"where table_schema = 'public' " + 
						"order by table_name;");
			
			String txt = null;
			while (rs.next()) {
				String tableName = rs.getString(1);
				
				if (txt == null)
					txt = tableName;
				else
					txt += "\n" + tableName;
			}
			
			if (txt != null)
				taTables.setText(txt);
			
			rs.close();
			st.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }
    
    private void saveHistory(String sql) {
    	File hFile = new File(fg.baseDir + "/sqlhistory.txt");
    	if (hFile.exists() == false) {
    		try {
				hFile.createNewFile();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
    	}
    		
    	String txt = null;
		try {
			txt = FileUtils.readFileToString(hFile, "UTF-8");
		} catch (IOException e) {
			e.printStackTrace();
		}
    	
		if (txt != null) {
			String a[] = txt.split("\n");
			
			boolean foundFlag = false;
			for(String s : a) {
				if (s.equals(sql) == true) {
					foundFlag = true;
					break;
				}
			}
			
			if (foundFlag == false) {
				Path path = Paths.get(hFile.getAbsolutePath());
				
				try {
					sql += "\n";
					Files.write(path, sql.getBytes(), StandardOpenOption.APPEND);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
    }

	@Override
	public void refreshScene() {
		fillList();
	}

	@Override
	public void leaveScene() {
		
	}

	@Override
	public void clickIt(String text, WidgetType widgetType) {
		
	}
}

